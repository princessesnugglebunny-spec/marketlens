const memStore = {};
function hasChrome() {
  return typeof chrome !== "undefined" && !!chrome.storage;
}
async function get(key, fallback) {
  if (hasChrome()) {
    return new Promise((resolve) => {
      chrome.storage.local.get([key], (res) => {
        resolve(res[key] ?? fallback);
      });
    });
  }
  return memStore[key] ?? fallback;
}
async function set(key, value) {
  if (hasChrome()) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ [key]: value }, () => resolve());
    });
  }
  memStore[key] = value;
}
export {
  get as g,
  set as s
};
