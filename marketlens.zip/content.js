import { g as get, s as set } from "./chunks/storage-qTEAP0fT.js";
const DEFAULT_FILTER_SETTINGS = {
  blockedWords: [],
  hideSponsored: true,
  hideShipping: true,
  hideAds: true,
  hideUnknown: false,
  seenMode: "fade"
};
const ITEM_LINK$1 = 'a[href*="/marketplace/item/"]';
function itemId(card) {
  const a = card.querySelector(ITEM_LINK$1);
  const m = a?.getAttribute("href")?.match(/\/marketplace\/item\/(\d+)/);
  return m ? m[1] : null;
}
function isSponsored(card) {
  const text = (card.textContent ?? "").toLowerCase();
  return text.includes("sponsored") || text.includes("boosted");
}
function isShipping(card) {
  const text = (card.textContent ?? "").toLowerCase();
  return text.includes("ships to you");
}
function isAd(card) {
  const text = (card.textContent ?? "").toLowerCase();
  return text.includes("ad from seller");
}
function hasBlockedKeyword(card, words) {
  const lower = (card.textContent ?? "").toLowerCase();
  for (const w of words) {
    if (w && lower.includes(w.toLowerCase())) return w;
  }
  return null;
}
function decideHide(card, settings, seenIds2, cityStatus) {
  if (settings.hideSponsored && isSponsored(card)) return "sponsored";
  const kw = hasBlockedKeyword(card, settings.blockedWords);
  if (kw) return "keyword";
  if (settings.hideShipping && isShipping(card)) return "shipping";
  if (settings.hideAds && isAd(card)) return "ad";
  if (cityStatus === "out") return "out-of-range";
  if (cityStatus === "unknown" && settings.hideUnknown) return "unknown-city";
  const id = itemId(card);
  if (id && seenIds2.has(id) && settings.seenMode === "hide") return "seen";
  return null;
}
function applyHide(card, reason, seen, seenMode) {
  const el = card;
  el.removeAttribute("data-mlf-hidden");
  el.style.opacity = "";
  if (reason) {
    card.setAttribute("data-mlf-hidden", reason);
    card.setAttribute("data-mlf-reason", reason);
  } else if (seen && seenMode === "fade") {
    card.style.opacity = "0.35";
    card.setAttribute("data-mlf-seen", "1");
  } else {
    card.removeAttribute("data-mlf-seen");
  }
}
const DEFAULT_SETTINGS = {
  radiusMiles: 40,
  graceMiles: 15,
  hideShipping: true,
  hideAds: true,
  hideUnknown: false,
  allowGrace: true
};
function parseCity(label) {
  const m = label.trim().match(/^(.+?),\s*([A-Za-z]{2,4})$/);
  if (!m) return null;
  return { city: m[1].trim(), state: m[2].toUpperCase() };
}
function distanceMiles(a, b) {
  const R = 3958.8;
  const toRad = (d) => d * Math.PI / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLon = toRad(b.lon - a.lon);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}
function classifyCity(listingCity, center, table, settings) {
  if (!listingCity || !center) return "unknown";
  const key = (c) => `${c.city.toLowerCase()}|${c.state.toLowerCase()}`;
  const lc = table.get(key(listingCity));
  const cc = table.get(key(center));
  if (!lc || !cc) return "unknown";
  const d = distanceMiles(lc, cc);
  const limit = settings.radiusMiles + (settings.allowGrace ? settings.graceMiles : 0);
  return d <= limit ? "in" : "out";
}
class MlfChat extends HTMLElement {
  messages = [];
  connectedCallback() {
    this.render();
  }
  render() {
    this.innerHTML = `
      <div style="display:flex;flex-direction:column;height:100%;font-family:sans-serif;">
        <div id="log" style="flex:1;overflow:auto;padding:8px;font-size:12px;"></div>
        <div style="display:flex;gap:4px;padding:8px;">
          <input id="input" type="text" style="flex:1;padding:4px;" placeholder="Ask MarketLens..." />
          <button id="send">Send</button>
        </div>
      </div>
    `;
    const send = this.querySelector("#send");
    const input = this.querySelector("#input");
    const log = this.querySelector("#log");
    send.addEventListener("click", async () => {
      const text = input.value.trim();
      if (!text) return;
      input.value = "";
      this.messages.push({ role: "user", content: text });
      log.innerHTML += `<div><b>You:</b> ${escapeHtml(text)}</div>`;
      const chromeApi = globalThis.chrome;
      const resp = await chromeApi?.runtime?.sendMessage?.({
        type: "chat",
        payload: { baseUrl: "", apiKey: "", model: "", messages: this.messages }
      });
      const reply = resp?.ok ? resp.text : `Error: ${resp?.error ?? "no response"}`;
      this.messages.push({ role: "assistant", content: reply });
      log.innerHTML += `<div><b>Agent:</b> ${escapeHtml(reply)}</div>`;
    });
  }
}
function escapeHtml(s) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
customElements.define("mlf-chat", MlfChat);
const DEFAULT_FEES = [
  { id: "ebay-us", name: "eBay US", fixed: 0.3, percent: 0.1325, processingPercent: 0, shipping: 0 },
  { id: "ebay-uk", name: "eBay UK", fixed: 0.3, percent: 0.128, processingPercent: 0, shipping: 0 },
  { id: "poshmark", name: "Poshmark", fixed: 0, percent: 0.2, processingPercent: 0, shipping: 0 },
  { id: "mercari", name: "Mercari", fixed: 0, percent: 0.1, processingPercent: 0.029, shipping: 0 },
  { id: "depop", name: "Depop", fixed: 0, percent: 0.1, processingPercent: 0.029, shipping: 0 },
  { id: "vinted", name: "Vinted", fixed: 0, percent: 0, processingPercent: 0, shipping: 0 },
  { id: "fb-shipping", name: "Facebook shipping", fixed: 0, percent: 0.05, processingPercent: 0, shipping: 0 },
  { id: "local-cash", name: "Local cash", fixed: 0, percent: 0, processingPercent: 0, shipping: 0 }
];
function totalFees(schedule, salePrice) {
  if (salePrice < 0) throw new Error("salePrice must be >= 0");
  const percentFee = salePrice * schedule.percent;
  const processingFee = salePrice * schedule.processingPercent;
  return schedule.fixed + percentFee + processingFee + schedule.shipping;
}
function netProfit(buyPrice, salePrice, schedule) {
  if (buyPrice < 0) throw new Error("buyPrice must be >= 0");
  return salePrice - buyPrice - totalFees(schedule, salePrice);
}
function maxBuyPrice(salePrice, targetRoi, schedule) {
  const fees = totalFees(schedule, salePrice);
  const keep = salePrice - fees;
  return keep / (1 + targetRoi);
}
function dealVerdict(profit, salePrice) {
  if (salePrice <= 0) return "pass";
  const margin = profit / salePrice;
  if (margin >= 0.3) return "good";
  if (margin >= 0.1) return "negotiate";
  return "pass";
}
function extractPrice(text) {
  const m = text.match(/\$\s*([\d,]+(?:\.\d{2})?)/);
  if (!m) return null;
  return Number(m[1].replace(/,/g, ""));
}
async function injectProfitPanel() {
  if (!location.pathname.startsWith("/marketplace/item/")) return;
  if (document.getElementById("mlf-profit-panel")) return;
  const price = extractPrice(document.body.textContent ?? "");
  if (price === null) return;
  const schedule = DEFAULT_FEES[0];
  const buyPrice = await get("mlf_last_buy", 0);
  const profit = netProfit(buyPrice, price, schedule);
  const maxBuy = maxBuyPrice(price, 0.3, schedule);
  const verdict = dealVerdict(profit, price);
  const panel = document.createElement("div");
  panel.id = "mlf-profit-panel";
  panel.style.cssText = "position:fixed;bottom:80px;right:12px;background:#0f172a;color:#fff;padding:12px;border-radius:8px;font-size:12px;z-index:2147483645;box-shadow:0 2px 8px rgba(0,0,0,.3);min-width:180px;";
  panel.innerHTML = `
    <div style="font-weight:700;margin-bottom:6px;">MarketLens Profit</div>
    <div>Sale: $${price.toFixed(2)}</div>
    <div>Fees: $${totalFees(schedule, price).toFixed(2)}</div>
    <div>Profit: $${profit.toFixed(2)}</div>
    <div>Max buy (30% ROI): $${maxBuy.toFixed(2)}</div>
    <div>Verdict: ${verdict}</div>
  `;
  document.body.appendChild(panel);
}
const RESTRICTED = ["eco-friendly", "non-toxic", "antibacterial", "bestseller", "full refund", "guarantee"];
function flagRestricted(text) {
  const lower = text.toLowerCase();
  return RESTRICTED.filter((r) => lower.includes(r));
}
function buildDraftPrompt(input) {
  const parts = [
    "You are a listing copywriter. Output JSON with keys: title, bullets (array of 5), description, searchTerms.",
    "Constraints: title <= 75 chars; no forbidden punctuation (! $ ? _ { } ^); no word more than twice; no ALL CAPS words; no promotional words; no restricted claims (eco-friendly, non-toxic, antibacterial, bestseller); no URLs/contact info/emojis; no guarantees/refunds; searchTerms <= 249 bytes.",
    `Seller notes: ${input.notes}`
  ];
  if (input.photoDescription) parts.push(`Photo description: ${input.photoDescription}`);
  return parts.join("\n");
}
function preflightNotes(notes) {
  return flagRestricted(notes);
}
function injectDraftPanel() {
  if (document.getElementById("mlf-draft-panel")) return;
  const panel = document.createElement("div");
  panel.id = "mlf-draft-panel";
  panel.style.cssText = "position:fixed;top:60px;right:12px;background:#0f172a;color:#fff;padding:12px;border-radius:8px;font-size:12px;z-index:2147483645;width:300px;box-shadow:0 2px 8px rgba(0,0,0,.3);";
  panel.innerHTML = `
    <div style="font-weight:700;margin-bottom:6px;">Draft Listing</div>
    <textarea id="mlf-notes" rows="4" style="width:100%;font-size:12px;" placeholder="Seller notes..."></textarea>
    <button id="mlf-draft-btn" style="margin-top:6px;padding:4px 8px;">Draft</button>
    <div id="mlf-draft-out" style="margin-top:8px;white-space:pre-wrap;max-height:200px;overflow:auto;"></div>
  `;
  document.body.appendChild(panel);
  const btn = panel.querySelector("#mlf-draft-btn");
  const notes = panel.querySelector("#mlf-notes");
  const out = panel.querySelector("#mlf-draft-out");
  btn.addEventListener("click", async () => {
    const text = notes.value.trim();
    if (!text) return;
    const restricted = preflightNotes(text);
    if (restricted.length) out.textContent = `Restricted claims flagged: ${restricted.join(", ")}
`;
    else out.textContent = "Drafting...";
    const chromeApi = globalThis.chrome;
    const resp = await chromeApi?.runtime?.sendMessage?.({
      type: "chat",
      payload: { baseUrl: "", apiKey: "", model: "", messages: [{ role: "user", content: buildDraftPrompt({ notes: text }) }] }
    });
    const reply = resp?.ok ? resp.text : `Error: ${resp?.error ?? "no response"}`;
    out.textContent = reply;
  });
}
const ITEM_LINK = 'a[href*="/marketplace/item/"]';
let filterSettings = { ...DEFAULT_FILTER_SETTINGS };
let geoSettings = { ...DEFAULT_SETTINGS };
const cityTable = /* @__PURE__ */ new Map();
let centerCity = null;
const seenIds = /* @__PURE__ */ new Set();
let hiddenCount = 0;
async function loadSettings() {
  filterSettings = {
    ...DEFAULT_FILTER_SETTINGS,
    blockedWords: (await get("mlf_blocked_words", "")).split(/\n/).map((s) => s.trim()).filter(Boolean)
  };
  const radius = await get("mlf_radius", DEFAULT_SETTINGS.radiusMiles);
  const grace = await get("mlf_grace", true);
  geoSettings = { ...DEFAULT_SETTINGS, radiusMiles: radius, allowGrace: grace };
  const seen = await get("mlf_seen_ids", []);
  seen.forEach((id) => seenIds.add(id));
}
async function loadCityTable() {
  try {
    for (const file of ["data/places.json", "data/aliases.json", "data/places-au.json", "data/places-nz.json"]) {
      const url = chrome.runtime.getURL(file);
      const res = await fetch(url);
      const data = await res.json();
      for (const [key, v] of Object.entries(data)) {
        const parts = key.split("|");
        if (parts.length !== 2) continue;
        const city = parts[0].trim();
        const state = parts[1].trim().toUpperCase();
        if (!cityTable.has(`${city.toLowerCase()}|${state.toLowerCase()}`)) {
          cityTable.set(`${city.toLowerCase()}|${state.toLowerCase()}`, {
            name: city.charAt(0).toUpperCase() + city.slice(1),
            state,
            lat: v[0],
            lon: v[1]
          });
        }
      }
    }
  } catch {
  }
}
function readFacebookLocation() {
  const btn = document.querySelector('[aria-label^="Location:"]');
  if (!btn) return;
  const label = btn.getAttribute("aria-label") ?? "";
  const m = label.match(/Location:\s*(.+?),\s*([A-Za-z]{2})/);
  if (m) {
    centerCity = { city: m[1].trim(), state: m[2].toUpperCase() };
    const rm = label.match(/Within\s+(\d+)\s*mi/);
    if (rm) geoSettings.radiusMiles = Number(rm[1]);
  }
}
function cellOf(anchor) {
  const id = itemId(anchor);
  if (!id) return null;
  let node = anchor;
  while (node && node.parentElement && node.parentElement !== document.body) {
    const parent = node.parentElement;
    const itemLinks = [...parent.querySelectorAll(ITEM_LINK)];
    if (itemLinks.some((l) => itemId(l) !== id)) break;
    const rect = parent.getBoundingClientRect();
    if (rect.width < 100 || rect.height < 100) break;
    if (rect.width > window.innerWidth * 0.95) break;
    node = parent;
  }
  return node;
}
function cardCity(card) {
  const lines = (card.textContent ?? "").split(/\n/).map((s) => s.trim()).filter(Boolean);
  for (const line of lines) {
    const p = parseCity(line);
    if (p) return p;
  }
  return null;
}
function processCard(card) {
  const id = itemId(card);
  if (!id) return;
  const cityStatus = classifyCity(cardCity(card), centerCity, cityTable, geoSettings);
  const reason = decideHide(card, filterSettings, seenIds, cityStatus);
  const isSeen = seenIds.has(id);
  applyHide(card, reason, isSeen, filterSettings.seenMode);
  if (reason) {
    hiddenCount += 1;
    void set("mlf_hidden_count", hiddenCount);
  }
  card.addEventListener("click", () => {
    if (!seenIds.has(id)) {
      seenIds.add(id);
      void set("mlf_seen_ids", [...seenIds]);
    }
  }, { once: true });
}
function scan() {
  readFacebookLocation();
  const anchors = document.querySelectorAll(ITEM_LINK);
  const cards = /* @__PURE__ */ new Set();
  anchors.forEach((a) => {
    const c = cellOf(a);
    if (c) cards.add(c);
  });
  cards.forEach(processCard);
}
function makeDraggable(el, key) {
  let dragging = false;
  let ox = 0;
  let oy = 0;
  el.addEventListener("mousedown", (e) => {
    dragging = true;
    ox = e.clientX - el.getBoundingClientRect().left;
    oy = e.clientY - el.getBoundingClientRect().top;
    el.style.cursor = "grabbing";
  });
  document.addEventListener("mousemove", (e) => {
    if (!dragging) return;
    el.style.left = `${e.clientX - ox}px`;
    el.style.top = `${e.clientY - oy}px`;
    el.style.right = "auto";
    el.style.bottom = "auto";
    el.style.transform = "none";
  });
  document.addEventListener("mouseup", () => {
    if (!dragging) return;
    dragging = false;
    el.style.cursor = "grab";
    void set(`mlf_pos_${key}`, { left: el.style.left, top: el.style.top });
  });
}
function mountShell() {
  if (document.getElementById("mlf-shell")) return;
  const shell = document.createElement("div");
  shell.id = "mlf-shell";
  shell.style.cssText = "position:fixed;inset:0;pointer-events:none;z-index:2147483646;";
  const fabStyle = "pointer-events:auto;position:fixed;width:46px;height:46px;border-radius:50%;border:1px solid rgba(255,255,255,.25);background:linear-gradient(135deg,#12805c,#0a5a3f);color:#fff;font-weight:700;cursor:grab;box-shadow:0 6px 18px rgba(18,128,92,.45),inset 0 1px 0 rgba(255,255,255,.2);backdrop-filter:blur(6px);transition:transform .15s,box-shadow .15s;font-size:16px;display:flex;align-items:center;justify-content:center;";
  const corners = ["top-left", "top-right", "bottom-left", "bottom-right"];
  corners.forEach((corner) => {
    const btn = document.createElement("button");
    btn.className = `mlf-fab mlf-fab--${corner}`;
    btn.textContent = "M";
    btn.style.cssText = fabStyle;
    const parts = corner.split("-");
    btn.style[parts[0]] = "14px";
    btn.style[parts[1]] = "14px";
    btn.addEventListener("mouseenter", () => {
      btn.style.transform = "scale(1.08)";
    });
    btn.addEventListener("mouseleave", () => {
      btn.style.transform = "scale(1)";
    });
    makeDraggable(btn, `fab-${corner}`);
    shell.appendChild(btn);
  });
  const chatBubble = document.createElement("button");
  chatBubble.textContent = "💬";
  chatBubble.style.cssText = fabStyle + "bottom:70px;right:14px;font-size:18px;";
  chatBubble.addEventListener("click", () => {
    const existing = document.getElementById("mlf-chat-panel");
    if (existing) {
      existing.remove();
      return;
    }
    const panel = document.createElement("div");
    panel.id = "mlf-chat-panel";
    panel.style.cssText = "pointer-events:auto;position:fixed;bottom:130px;right:14px;width:320px;height:380px;background:rgba(15,23,42,.92);color:#fff;border-radius:16px;box-shadow:0 12px 32px rgba(0,0,0,.4);backdrop-filter:blur(10px);border:1px solid rgba(255,255,255,.12);overflow:hidden;";
    const chat = document.createElement("mlf-chat");
    chat.style.cssText = "display:block;height:100%;";
    panel.appendChild(chat);
    shell.appendChild(panel);
  });
  shell.appendChild(chatBubble);
  const barStyle = "pointer-events:auto;position:fixed;left:50%;transform:translateX(-50%);background:rgba(15,23,42,.78);color:#fff;padding:6px 16px;border-radius:999px;font-size:12px;opacity:0.92;cursor:pointer;backdrop-filter:blur(8px);border:1px solid rgba(255,255,255,.12);box-shadow:0 4px 14px rgba(0,0,0,.25);transition:opacity .2s,transform .2s;";
  const topBar = document.createElement("div");
  topBar.className = "mlf-bar mlf-bar--top";
  topBar.textContent = "MarketLens";
  topBar.style.cssText = barStyle + "top:10px;";
  let topCollapsed = false;
  topBar.addEventListener("click", () => {
    topCollapsed = !topCollapsed;
    topBar.style.opacity = topCollapsed ? "0.35" : "0.92";
    topBar.textContent = topCollapsed ? "ML" : "MarketLens";
    void set("mlf_top_collapsed", topCollapsed);
  });
  shell.appendChild(topBar);
  const bottomBar = document.createElement("div");
  bottomBar.className = "mlf-bar mlf-bar--bottom";
  bottomBar.textContent = "Notifications";
  bottomBar.style.cssText = barStyle + "bottom:10px;";
  let bottomCollapsed = false;
  bottomBar.addEventListener("click", () => {
    bottomCollapsed = !bottomCollapsed;
    bottomBar.style.opacity = bottomCollapsed ? "0.35" : "0.92";
    bottomBar.textContent = bottomCollapsed ? "N" : "Notifications";
    void set("mlf_bottom_collapsed", bottomCollapsed);
  });
  shell.appendChild(bottomBar);
  document.documentElement.appendChild(shell);
}
async function init() {
  await loadSettings();
  await loadCityTable();
  mountShell();
  void injectProfitPanel();
  injectDraftPanel();
  scan();
  const obs = new MutationObserver(() => scan());
  obs.observe(document.body, { childList: true, subtree: true });
}
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", () => void init());
} else {
  void init();
}
