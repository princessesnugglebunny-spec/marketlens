import { g as get, s as set } from "./chunks/storage-qTEAP0fT.js";
async function render() {
  const root = document.getElementById("app");
  if (!root) return;
  const enabled = await get("mlf_enabled", true);
  const hidden = await get("mlf_hidden_count", 0);
  const grace = await get("mlf_grace", true);
  root.innerHTML = `
    <div style="font-family:sans-serif;padding:12px;min-width:240px;">
      <h3 style="margin:0 0 8px;">MarketLens</h3>
      <p>Hidden on this page: <strong>${hidden}</strong></p>
      <label><input type="checkbox" id="enabled" ${enabled ? "checked" : ""}/> Enabled</label><br/>
      <label><input type="checkbox" id="grace" ${grace ? "checked" : ""}/> Allow 15mi grace</label>
      <p style="margin-top:8px;"><a href="#" id="options">Settings</a></p>
    </div>
  `;
  document.getElementById("enabled")?.addEventListener("change", (e) => {
    void set("mlf_enabled", e.target.checked);
  });
  document.getElementById("grace")?.addEventListener("change", (e) => {
    void set("mlf_grace", e.target.checked);
  });
  document.getElementById("options")?.addEventListener("click", (e) => {
    e.preventDefault();
    chrome.runtime.openOptionsPage();
  });
}
render();
