import { g as get, s as set } from "./chunks/storage-qTEAP0fT.js";
const scriptRel = "modulepreload";
const assetsURL = function(dep) {
  return "/" + dep;
};
const seen = {};
const __vitePreload = function preload(baseModule, deps, importerUrl) {
  let promise = Promise.resolve();
  if (deps && deps.length > 0) {
    document.getElementsByTagName("link");
    const cspNonceMeta = document.querySelector(
      "meta[property=csp-nonce]"
    );
    const cspNonce = cspNonceMeta?.nonce || cspNonceMeta?.getAttribute("nonce");
    promise = Promise.allSettled(
      deps.map((dep) => {
        dep = assetsURL(dep);
        if (dep in seen) return;
        seen[dep] = true;
        const isCss = dep.endsWith(".css");
        const cssSelector = isCss ? '[rel="stylesheet"]' : "";
        if (document.querySelector(`link[href="${dep}"]${cssSelector}`)) {
          return;
        }
        const link = document.createElement("link");
        link.rel = isCss ? "stylesheet" : scriptRel;
        if (!isCss) {
          link.as = "script";
        }
        link.crossOrigin = "";
        link.href = dep;
        if (cspNonce) {
          link.setAttribute("nonce", cspNonce);
        }
        document.head.appendChild(link);
        if (isCss) {
          return new Promise((res, rej) => {
            link.addEventListener("load", res);
            link.addEventListener(
              "error",
              () => rej(new Error(`Unable to preload CSS for ${dep}`))
            );
          });
        }
      })
    );
  }
  function handlePreloadError(err) {
    const e = new Event("vite:preloadError", {
      cancelable: true
    });
    e.payload = err;
    window.dispatchEvent(e);
    if (!e.defaultPrevented) {
      throw err;
    }
  }
  return promise.then((res) => {
    for (const item of res || []) {
      if (item.status !== "rejected") continue;
      handlePreloadError(item.reason);
    }
    return baseModule().catch(handlePreloadError);
  });
};
async function listEntries() {
  return get("mlf_buy_log", []);
}
function toCsv(entries) {
  const header = "id,title,buyPrice,sellPrice,platform,status,createdAt";
  const rows = entries.map(
    (e) => [e.id, `"${e.title.replace(/"/g, '""')}"`, e.buyPrice, e.sellPrice, e.platform, e.status, new Date(e.createdAt).toISOString()].join(",")
  );
  return [header, ...rows].join("\n");
}
const buylog = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  listEntries,
  toCsv
}, Symbol.toStringTag, { value: "Module" }));
function summarize(entries) {
  const sold = entries.filter((e) => e.status === "sold");
  const revenue = sold.reduce((a, e) => a + e.sellPrice, 0);
  const cost = sold.reduce((a, e) => a + e.buyPrice, 0);
  const profit = revenue - cost;
  const days = sold.map((e) => (Date.now() - e.createdAt) / (1e3 * 60 * 60 * 24));
  const avgDaysToSell = days.length ? days.reduce((a, b) => a + b, 0) / days.length : 0;
  const turnoverRate = entries.length ? sold.length / entries.length : 0;
  return {
    totalItems: entries.length,
    soldCount: sold.length,
    revenue,
    profit,
    avgDaysToSell: Math.round(avgDaysToSell * 10) / 10,
    turnoverRate: Math.round(turnoverRate * 100) / 100
  };
}
async function render() {
  const root = document.getElementById("app");
  if (!root) return;
  const words = await get("mlf_blocked_words", "");
  const apiBase = await get("mlf_api_base", "");
  const apiKey = await get("mlf_api_key", "");
  const apiModel = await get("mlf_api_model", "gpt-4o-mini");
  const radius = await get("mlf_radius", 40);
  const grace = await get("mlf_grace", true);
  root.innerHTML = `
    <div style="font-family:sans-serif;padding:24px;max-width:760px;margin:0 auto;">
      <h1>MarketLens Settings</h1>
      <h2>Blocked words (one per line)</h2>
      <textarea id="words" rows="6" style="width:100%;">${escapeHtml(words)}</textarea>

      <h2>Geo filter</h2>
      <label>Radius (mi): <input id="radius" type="number" value="${radius}" /></label>
      <label style="margin-left:12px;"><input id="grace" type="checkbox" ${grace ? "checked" : ""}/> Allow 15mi grace</label>

      <h2>OpenAI-compatible API</h2>
      <label>Base URL: <input id="apiBase" type="text" value="${escapeHtml(apiBase)}" style="width:100%;" placeholder="https://api.openai.com/v1" /></label><br/>
      <label>API Key: <input id="apiKey" type="password" value="${escapeHtml(apiKey)}" style="width:100%;" /></label><br/>
      <label>Model: <input id="apiModel" type="text" value="${escapeHtml(apiModel)}" style="width:100%;" /></label>

      <h2>Buy log &amp; analytics</h2>
      <div id="analytics"></div>
      <p><button id="exportCsv">Export CSV</button></p>

      <p style="margin-top:16px;"><button id="save">Save</button> <span id="status"></span></p>
    </div>
  `;
  (async () => {
    const entries = await listEntries();
    const a = summarize(entries);
    const el = document.getElementById("analytics");
    if (el) el.innerHTML = `<p>Items: ${a.totalItems} | Sold: ${a.soldCount} | Revenue: $${a.revenue.toFixed(2)} | Profit: $${a.profit.toFixed(2)} | Avg days to sell: ${a.avgDaysToSell} | Turnover: ${a.turnoverRate}</p>`;
  })();
  document.getElementById("exportCsv")?.addEventListener("click", async () => {
    const { toCsv: toCsv2 } = await __vitePreload(async () => {
      const { toCsv: toCsv3 } = await Promise.resolve().then(() => buylog);
      return { toCsv: toCsv3 };
    }, true ? void 0 : void 0);
    const entries = await listEntries();
    const csv = toCsv2(entries);
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "buylog.csv";
    a.click();
    URL.revokeObjectURL(url);
  });
  document.getElementById("save")?.addEventListener("click", async () => {
    await set("mlf_blocked_words", document.getElementById("words").value);
    await set("mlf_radius", Number(document.getElementById("radius").value));
    await set("mlf_grace", document.getElementById("grace").checked);
    await set("mlf_api_base", document.getElementById("apiBase").value);
    await set("mlf_api_key", document.getElementById("apiKey").value);
    await set("mlf_api_model", document.getElementById("apiModel").value);
    const status = document.getElementById("status");
    if (status) status.textContent = "Saved";
  });
}
function escapeHtml(s) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
render();
